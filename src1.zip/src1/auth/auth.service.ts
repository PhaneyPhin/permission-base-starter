import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  private users = [
    { id: 1, username: 'admin', password: '$2b$10$gq05wfLC2vogO35Jmn8qJeIx1sVPsBaHhmOw8c85unwd1liCV31uG', roles: ['admin'] }, // bcrypt hash of 'password'
    { id: 2, username: 'user', password: '$2b$10$gq05wfLC2vogO35Jmn8qJeIx1sVPsBaHhmOw8c85unwd1liCV31uG', roles: ['user'] },
  ];

  constructor(private readonly jwtService: JwtService) {}

  async validateUser(username: string, password: string): Promise<any> {
    const user = this.users.find((u) => u.username === username);
    if (user && (await bcrypt.compare(password, user.password))) {
      const { password, ...result } = user;
      return result;
    }

    bcrypt.hashsync()
    throw new UnauthorizedException('Invalid credentials');
  }

  async login(user: any) {
    const payload = { username: user.username, sub: user.id, roles: user.roles };
    console.log(payload)
    return { access_token: this.jwtService.sign(payload) };
  }
}
