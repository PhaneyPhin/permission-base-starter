import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from './entities/user.entities';
import { Repository } from 'typeorm';
import { CreateUserDto } from './dto/create-user.dto';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  private readonly users = [
    { id: 1, username: 'admin', roles: ['admin'] },
    { id: 2, username: 'user', roles: ['user'] },
  ];

  getAllUser() {
    return this.userRepository.find({})
  }

  async create(userDto: CreateUserDto) {
     const user = await this.userRepository.create(userDto)
     
     return await this.userRepository.save(user)
  }
  findByUsername(username: string) {
    return this.users.find((user) => user.username === username);
  }

  findById(id: number) {
    return this.users.find((user) => user.id === id);
  }
}
