import { Body, Controller, Get, HttpStatus, Post, Req, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles } from '../auth/roles.decorator';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';

@Controller('users')
@ApiTags('Users') // Groups the endpoints under "Users" in Swagger
@ApiBearerAuth() // Adds the BearerAuth requirement for these endpoints
@UseGuards(JwtAuthGuard, RolesGuard)
export class UserController {
  constructor(private readonly userService: UserService) {

  }
  @Get('/')
  @Roles('user', 'admin')
  @ApiOperation({ summary: 'Get user List' })
  @ApiResponse({ status: 200, description: 'Successfully retrieved user list.' })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  getAllUser(@Req() req: any) {
    return this.userService.getAllUser()
  }

  @Post('/')
  @Roles('user', 'admin')
  @ApiOperation({ summary: 'Create user' })
  @ApiResponse({ status: 201, description: 'Successfully create profile.' })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  createUser(@Body() userDto: CreateUserDto) {
    return this.userService.create(userDto)
  }

  @Get('profile')
  @Roles('user', 'admin')
  @ApiOperation({ summary: 'Get user profile' })
  @ApiResponse({ status: 200, description: 'Successfully retrieved profile.' })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  getProfile(@Req() req: any) {
    return { message: 'Welcome!', user: req.user };
  }

  @Get('admin')
  @Roles('admin')
  @ApiOperation({ summary: 'Admin-only route' })
  @ApiResponse({ status: 200, description: 'Access granted for admin.' })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  adminRoute(@Req() req: any) {
    return { message: 'Admin only route', user: req.user };
  }
}
