import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { UnprocessableEntityException, ValidationPipe } from '@nestjs/common';
import { ValidationError } from 'class-validator';

async function bootstrap() {
  const app = (await NestFactory.create(AppModule)).setGlobalPrefix('/api/v1');
  
  // Swagger configuration
  const config = new DocumentBuilder()
    .setTitle('Role and Permission API')
    .setDescription('API for managing roles, permissions, and authentication')
    .setVersion('1.0')
    .addBearerAuth() // Add JWT Bearer authentication
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document); // Swagger available at /api
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true, // Remove non-whitelisted properties
      forbidNonWhitelisted: true, // Throw an error for non-whitelisted properties
      transform: true, // Automatically transform payloads to DTO instances
      exceptionFactory: (errors: ValidationError[]) => {
        const formattedErrors = errors.map(err => ({
          path: err.property,
          message: Object.values(err.constraints || {}).join(', '),
        }));
        return new UnprocessableEntityException({ errors: formattedErrors });
      },
    }),
  );

  await app.listen(3000);
}
bootstrap();
